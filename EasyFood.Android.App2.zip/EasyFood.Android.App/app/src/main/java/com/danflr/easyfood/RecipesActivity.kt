package com.danflr.easyfood

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.android.volley.RequestQueue
import com.android.volley.toolbox.Volley
import com.danflr.easyfood.adapters.RecipesAdapter
import com.danflr.easyfood.helpers.RequestHelper
import com.danflr.easyfood.interfaces.ResponseCallback
import com.danflr.easyfood.models.Recipe
import kotlinx.android.synthetic.main.activity_recipes.*
import org.json.JSONArray

class RecipesActivity : AppCompatActivity() {

    lateinit var queue: RequestQueue
    lateinit var recipes: ArrayList<Recipe>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recipes)

        queue = Volley.newRequestQueue(this)
        recipes = ArrayList<Recipe>()
        val act = this

        refresher.isRefreshing = true

        refresher.setOnRefreshListener {
            RequestHelper(this).getRecipes(queue, object: ResponseCallback {
                override fun onSuccessResponse(response: JSONArray) {
                    for(i in 0 .. response.length() - 1){
                        recipes.add(Recipe(response.getJSONObject(i)))
                    }

                    lvRecipes.adapter = RecipesAdapter(recipes, act, queue)
                    refresher.isRefreshing = false
                }

                override fun onErrorResponse() {
                    refresher.isRefreshing = false
                }
            })
        }

        RequestHelper(this).getRecipes(queue, object: ResponseCallback {
            override fun onSuccessResponse(response: JSONArray) {
                for(i in 0 .. response.length() - 1){
                    recipes.add(Recipe(response.getJSONObject(i)))
                }

                lvRecipes.adapter = RecipesAdapter(recipes, act, queue)
                refresher.isRefreshing = false
            }

            override fun onErrorResponse() {
                refresher.isRefreshing = false
            }
        })

    }
}
