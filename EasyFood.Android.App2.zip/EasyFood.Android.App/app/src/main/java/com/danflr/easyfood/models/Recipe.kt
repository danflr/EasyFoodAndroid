package com.danflr.easyfood.models

import com.google.gson.GsonBuilder
import org.json.JSONObject


class Recipe {
    lateinit var Recipe_Name: String
    lateinit var Recipe_Id: String
    var Likes: Int = 0
    lateinit var User: String
    lateinit var PostDate: String
    var Comments: Int = 0
    lateinit var Category: String
    lateinit var CommentsList: ArrayList<Comment>
    lateinit var Ingredients: ArrayList<Ingredient>
    lateinit var Posted_By: String
    lateinit var Category_Id: String

    constructor(username: String, poster: String){
        this.Recipe_Name = ""
        this.Recipe_Id = ""
        this.Likes = 0
        this.User = username
        this.PostDate = ""
        this.Comments = 0
        this.Category = ""
        this.CommentsList = ArrayList<Comment>()
        this.Ingredients = ArrayList<Ingredient>()
        this.Posted_By = poster
        this.Category_Id = ""
    }

    constructor(data: JSONObject){
        this.Recipe_Id = if(!data.isNull("recipe_Id")) data.getString("recipe_Id") else ""
        this.Recipe_Name = if(!data.isNull("recipe_Name")) data.getString("recipe_Name") else ""
        this.Likes = if(!data.isNull("likes")) data.getInt("likes") else 0
        this.User = if(!data.isNull("user")) data.getString("user") else ""
        this.PostDate = if(!data.isNull("postDate")) data.getString("postDate") else ""
        this.Comments = if(!data.isNull("comments")) data.getInt("comments") else 0
        this.Category = if(!data.isNull("category")) data.getString("category") else ""
        this.CommentsList = ArrayList<Comment>()
        this.Ingredients = ArrayList<Ingredient>()
        this.Posted_By = if(!data.isNull("posted_By")) data.getString("posted_By") else ""
        this.Category_Id = if(!data.isNull("category_Id")) data.getString("category_Id") else ""
        if(!data.isNull("commentsList")){
            for(i in 0 .. data.getJSONArray("commentsList").length() - 1){
                this.CommentsList.add(Comment(data.getJSONArray("commentsList").getJSONObject(i)))
            }
        }
        if(!data.isNull("ingredients")){
            for(i in 0 .. data.getJSONArray("ingredients").length() - 1){
                this.CommentsList.add(Comment(data.getJSONArray("ingredients").getJSONObject(i)))
            }
        }
    }

    fun toJson() : String {
        return GsonBuilder().setPrettyPrinting().create().toJson(this)
    }



}