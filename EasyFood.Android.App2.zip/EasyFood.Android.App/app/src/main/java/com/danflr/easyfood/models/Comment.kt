package com.danflr.easyfood.models

import com.google.gson.GsonBuilder
import org.json.JSONObject

class Comment {
    lateinit var Comment_Id: String
    lateinit var Recipe_Id: String
    lateinit var Account_Id: String
    lateinit var User: String
    lateinit var Content: String
    lateinit var Posted_On: String

    constructor(recipeId: String, accountId: String, content: String){
        this.Recipe_Id = recipeId
        this.Account_Id = accountId
        this.Content = content
    }

    constructor(data: JSONObject){
        this.Comment_Id = if(!data.isNull("Comment_Id")) data.getString("Comment_Id") else ""
        this.Recipe_Id = if(!data.isNull("Recipe_Id")) data.getString("Recipe_Id") else ""
        this.Account_Id = if(!data.isNull("Account_Id")) data.getString("Account_Id") else ""
        this.User = if(!data.isNull("User")) data.getString("User") else ""
        this.Content = if(!data.isNull("Content")) data.getString("Content") else ""
        this.Posted_On = if(!data.isNull("Posted_On")) data.getString("Posted_On") else ""
    }

    fun toJson() : String {
        return GsonBuilder().setPrettyPrinting().create().toJson(this)
    }

}